# LICENSE #

Leap Bootstrap Theme by Medium Rare

Use of this theme is subject to the license terms set out on the Bootstrap Themes site:

https://themes.getbootstrap.com/licenses/
