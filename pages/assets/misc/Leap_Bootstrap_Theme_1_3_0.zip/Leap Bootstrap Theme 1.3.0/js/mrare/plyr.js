//
//
// plyr.js
//
// Initialises the plyr video and audio player

import Plyr from 'plyr';

Plyr.setup('[data-provider],.plyr');
